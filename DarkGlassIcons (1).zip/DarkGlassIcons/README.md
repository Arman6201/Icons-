# Dark Glass Icons

iOS-style dark icon pack for Lawnchair (and Nova, etc.).

## Build
**A) Android Studio (PC):** File > Open this folder, let Gradle sync, Build > Build APK(s).
**B) No PC:** make a free GitHub repo, upload all files (keep the .github folder), open the Actions tab,
run "Build APK", download the APK from the run's Artifacts.

## Use
Install the APK, then Lawnchair: long-press home > Home settings > Icons > Icon pack > Dark Glass Icons.

## Add or fix an icon
1. Drop a vector in app/src/main/res/drawable/ (copy any existing one as a template, 108x108 viewport).
2. Add a line to BOTH res/xml/appfilter.xml and assets/appfilter.xml:
   <item component="ComponentInfo{package/Activity}" drawable="name"/>
3. Add <item drawable="name"/> to res/xml/drawable.xml and assets/drawable.xml.
Apps without an entry get their own icon on the dark squircle (iconback/iconmask/scale 0.62).
In Lawnchair you can also long-press an app > Edit > pick any icon from the pack by hand.
