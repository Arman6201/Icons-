package com.darkglass.icons;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView t = new TextView(this);
        t.setPadding(56, 120, 56, 56);
        t.setTextSize(16);
        t.setText("Dark Glass Icons\n\nTo apply in Lawnchair:\nLong-press home > Home settings > Icons > Icon pack > Dark Glass Icons.\n\nApps without a custom glyph get their own icon on a dark squircle.");
        setContentView(t);
    }
}
